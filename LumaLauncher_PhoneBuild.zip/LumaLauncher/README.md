# Luma Launcher

A minimal, Lumia-inspired Android launcher built with native Java and no third-party dependencies.

## Features
- Home launcher role via Android HOME intent filter
- Large clock/date header
- Minimal live-style tiles with asymmetric layout
- App drawer populated from installed launcher apps
- App search overlay
- Tap an app to launch it
- Swipe up/down between home and app drawer
- Dark, low-distraction visual system
- No external SDKs or libraries

## Build
Open this project in current Android Studio. The project targets Android API 37 and uses Android Gradle Plugin 9.4.0 with Gradle 9.6.0.

Run:
`./gradlew assembleDebug`

The APK will be at:
`app/build/outputs/apk/debug/app-debug.apk`

After installing, press the Home button and choose **Luma Launcher** as the default launcher.

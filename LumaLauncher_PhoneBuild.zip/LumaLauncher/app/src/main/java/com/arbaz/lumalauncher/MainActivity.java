package com.arbaz.lumalauncher;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.text.TextWatcher;
import android.text.Editable;

import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LauncherSurface surface;
    FrameLayout root;
    EditText search;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(11,13,16));
        getWindow().setNavigationBarColor(Color.rgb(11,13,16));
        getWindow().getDecorView().setSystemUiVisibility(0);
        root = new FrameLayout(this);
        surface = new LauncherSurface(this);
        root.addView(surface, new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
    }

    void openSearch() {
        if (search != null) return;
        search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("Search apps");
        search.setTextColor(Color.WHITE);
        search.setHintTextColor(Color.rgb(130,138,148));
        search.setTextSize(18);
        search.setBackgroundColor(Color.rgb(25,29,35));
        search.setPadding(22, 0, 22, 0);
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(-1, 58);
        p.leftMargin = 18; p.rightMargin = 18; p.topMargin = 66;
        root.addView(search, p);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int a,int c,int d){}
            public void onTextChanged(CharSequence s,int a,int b,int c){ surface.filter = s.toString(); surface.invalidate(); }
            public void afterTextChanged(Editable e){}
        });
        search.requestFocus();
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(search, InputMethodManager.SHOW_IMPLICIT);
    }

    void closeSearch() {
        if (search == null) return;
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(search.getWindowToken(), 0);
        root.removeView(search); search = null;
    }

    @Override public void onBackPressed() {
        if (search != null) { closeSearch(); surface.invalidate(); return; }
        if (surface.drawer) { surface.drawer=false; surface.invalidate(); return; }
        super.onBackPressed();
    }

    class LauncherSurface extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        boolean drawer=false;
        String filter="";
        ArrayList<AppItem> apps = new ArrayList<>();
        ArrayList<RectF> hit = new ArrayList<>();
        ArrayList<AppItem> hitApps = new ArrayList<>();
        long lastTap=0;
        float downX,downY;

        final int BG = Color.rgb(11,13,16), FG = Color.rgb(244,246,249), MUTED=Color.rgb(139,146,156);
        final int BLUE=Color.rgb(74,168,255), TILE=Color.rgb(27,31,37), LIGHT=Color.rgb(34,39,46);
        final int ACCENT2=Color.rgb(112,205,179);

        LauncherSurface(Context c){ super(c); setFocusable(true); loadApps(); }

        void loadApps(){
            PackageManager pm=getPackageManager();
            Intent i=new Intent(Intent.ACTION_MAIN,null); i.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ApplicationInfo> list=pm.getInstalledApplications(PackageManager.GET_META_DATA);
            HashSet<String> skip=new HashSet<>(); skip.add(getPackageName());
            for(ApplicationInfo ai:list){
                if(skip.contains(ai.packageName)) continue;
                Intent launch=pm.getLaunchIntentForPackage(ai.packageName);
                if(launch==null) continue;
                String n=ai.loadLabel(pm).toString();
                apps.add(new AppItem(n,ai.packageName,ai.loadIcon(pm),launch));
            }
            apps.sort(Comparator.comparing(a->a.name.toLowerCase(Locale.getDefault())));
        }

        @Override protected void onDraw(Canvas c){ super.onDraw(c); c.drawColor(BG); if(drawer) drawDrawer(c); else drawHome(c); }

        void setupText(float size,int color,Paint.Align align){ text.setTypeface(Typeface.create("sans",Typeface.NORMAL)); text.setTextSize(size); text.setColor(color); text.setTextAlign(align); }

        void drawHome(Canvas c){
            float w=getWidth(), h=getHeight();
            setupText(Math.min(w,h)*0.050f,FG,Paint.Align.LEFT);
            String time=new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date());
            c.drawText(time,22,68,text);
            setupText(15,MUTED,Paint.Align.LEFT);
            String day=new SimpleDateFormat("EEEE, d MMMM",Locale.getDefault()).format(new Date());
            c.drawText(day,24,95,text);

            setupText(12,MUTED,Paint.Align.RIGHT);
            c.drawText("LUMA",w-22,45,text);

            float left=20, gap=10, top=132;
            float cw=(w-left*2-gap)/2f;
            float ch=Math.min(150, (h-top-150-gap*3)/4f);
            tile(c,left,top,cw,ch,BLUE,"PHONE",getGlyph("⌕"),"Recent calls");
            tile(c,left+cw+gap,top,cw,ch,TILE,"MESSAGES",getGlyph("□"),"2 unread");
            tile(c,left,top+ch+gap,cw*1.5f+gap,ch,ACCENT2,"MUSIC",getGlyph("♪"),"Now playing");
            tile(c,left+cw*1.5f+gap*2,top+ch+gap,cw*0.5f-gap,ch, LIGHT,"CAMERA",getGlyph("○"),"Capture");
            tile(c,left,top+(ch+gap)*2,cw,ch*1.25f,TILE,"WEATHER",getGlyph("☼"),"28°   CLEAR");
            tile(c,left+cw+gap,top+(ch+gap)*2,cw,ch*1.25f,BLUE,"MAPS",getGlyph("⌖"),"Nearby");
            float bottom=h-76;
            p.setColor(Color.rgb(25,29,34)); c.drawRect(20,bottom,w-20,bottom+48,p);
            setupText(14,FG,Paint.Align.LEFT); c.drawText("ALL APPS",38,bottom+30,text);
            setupText(13,MUTED,Paint.Align.RIGHT); c.drawText("↑",w-38,bottom+30,text);
        }

        String getGlyph(String s){ return s; }

        void tile(Canvas c,float x,float y,float ww,float hh,int color,String title,String glyph,String sub){
            p.setColor(color); c.drawRect(x,y,x+ww,y+hh,p);
            setupText(Math.max(10,ww*0.055f),Color.WHITE,Paint.Align.LEFT); c.drawText(glyph,x+16,y+42,text);
            setupText(Math.max(9,ww*0.046f),Color.argb(220,255,255,255),Paint.Align.LEFT); c.drawText(title,x+16,y+hh-33,text);
            setupText(Math.max(8,ww*0.036f),Color.argb(175,255,255,255),Paint.Align.LEFT); c.drawText(sub,x+16,y+hh-13,text);
        }

        void drawDrawer(Canvas c){
            float w=getWidth(), h=getHeight();
            setupText(36,FG,Paint.Align.LEFT); c.drawText("apps",22,65,text);
            setupText(13,MUTED,Paint.Align.RIGHT); c.drawText(apps.size()+" installed",w-22,60,text);
            hit.clear(); hitApps.clear();
            float y=104, row=66;
            for(AppItem a:apps){
                if(!filter.isEmpty() && !a.name.toLowerCase(Locale.getDefault()).contains(filter.toLowerCase(Locale.getDefault()))) continue;
                p.setColor(TILE); c.drawRect(18,y,w-18,y+54,p);
                drawIcon(c,a.icon,28,y+7,40,40);
                setupText(16,FG,Paint.Align.LEFT); c.drawText(a.name,82,y+34,text);
                hit.add(new RectF(18,y,w-18,y+54)); hitApps.add(a);
                y += row;
                if(y>h-20) break;
            }
            setupText(12,MUTED,Paint.Align.LEFT); c.drawText("Swipe up for more",22,h-22,text);
        }

        void drawIcon(Canvas c,Drawable d,float x,float y,float ww,float hh){ if(d==null)return; d.setBounds((int)x,(int)y,(int)(x+ww),(int)(y+hh)); d.draw(c); }

        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()==MotionEvent.ACTION_DOWN){downX=e.getX();downY=e.getY();return true;}
            if(e.getAction()==MotionEvent.ACTION_UP){
                float dx=e.getX()-downX, dy=e.getY()-downY;
                if(Math.abs(dx)>60 || Math.abs(dy)>60){
                    if(!drawer && dy<0){drawer=true;invalidate();}
                    else if(drawer && dy>0){drawer=false;closeSearch();invalidate();}
                    return true;
                }
                handleTap(e.getX(),e.getY()); return true;
            }
            return true;
        }

        void handleTap(float x,float y){
            if(drawer){
                for(int i=0;i<hit.size();i++) if(hit.get(i).contains(x,y)){ try{startActivity(hitApps.get(i).intent);}catch(Exception ignored){} return; }
                if(y<90){ openSearch(); return; }
            }else{
                float h=getHeight(), w=getWidth();
                if(y>h-90){drawer=true;invalidate();return;}
                if(y>48 && y<110){openSearch();return;}
                // Long-ish double tap on home opens system launcher settings / default apps.
                long now=System.currentTimeMillis();
                if(now-lastTap<350 && y<120){
                    try{startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));}catch(Exception ignored){}
                }
                lastTap=now;
            }
        }
    }

    static class AppItem {
        final String name, packageName; final Drawable icon; final Intent intent;
        AppItem(String n,String p,Drawable d,Intent i){name=n;packageName=p;icon=d;intent=i;}
    }
}

# Build the APK from your Pixel 10a

This project can be built in GitHub Actions without a PC.

1. In your phone browser, open https://github.com/new and create a new empty repository named `LumaLauncher`.
2. Upload the contents of this folder to the repository, keeping the `.github/workflows/build-apk.yml` path. The simplest method is GitHub's web **Add file → Upload files**; if your GitHub upload UI does not preserve the hidden `.github` path, create the workflow file using **Add file → Create new file** and paste the contents of `.github/workflows/build-apk.yml`.
3. Commit the files to the `main` branch.
4. Open the repository's **Actions** tab and select **Build Luma Launcher APK**. Run it if it has not started automatically.
5. Wait for the green checkmark.
6. Open that workflow run, scroll to **Artifacts**, and download `LumaLauncher-Pixel10a-APK`.
7. Extract the downloaded ZIP on your Pixel 10a. Tap `app-debug.apk` to install it.
8. If Android blocks installation, allow your browser/files app to install unknown apps when prompted.
9. Go to **Settings → Apps → Default apps → Home app** and select **Luma Launcher**.

The APK is a debug-signed universal Android APK and is intended for personal installation on the Pixel 10a.
